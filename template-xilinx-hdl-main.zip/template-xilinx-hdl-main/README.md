# template-xilinx-hdl
Template used for creating new Xilinx Vivado projects
